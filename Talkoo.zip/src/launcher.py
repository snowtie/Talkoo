from __future__ import annotations
import hashlib
import os
import sys
import subprocess
import time
from pathlib import Path
from shutil import which

def get_base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent

def get_system_python() -> list[str]:
    if os.name == "nt":
        if which("py"):
            try:
                subprocess.check_call(["py", "-3.11", "-c", "import sys;print(1)"],
                                      stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=5)
                return ["py", "-3.11"]
            except Exception:
                pass
        p = which("python3.11")
        if p:
            return [p]
        if which("py"):
            try:
                subprocess.check_call(["py", "-3", "-c", "import sys;print(1)"],
                                      stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=5)
                return ["py", "-3"]
            except Exception:
                pass
        for exe in ("python.exe", "python3.exe"):
            p = which(exe)
            if p:
                return [p]
    else:
        for exe in ("python3.11", "python3", "python"):
            p = which(exe)
            if p:
                return [p]
    return []

BASE_DIR = get_base_dir()
RUNTIME_DIR = BASE_DIR / ".runtime"
VENV_DIR = RUNTIME_DIR / "venv"

if os.name == "nt":
    PY_EXE = VENV_DIR / "Scripts" / "python.exe"
    PIP_EXE = VENV_DIR / "Scripts" / "pip.exe"
else:
    PY_EXE = VENV_DIR / "bin" / "python3"
    PIP_EXE = VENV_DIR / "bin" / "pip3"

REQ_FILE = BASE_DIR / "requirements.txt"
REQ_HASH_FILE = RUNTIME_DIR / ".req_hash"
HP_FILE = BASE_DIR / "HP.txt"
MAIN_FILE = BASE_DIR / "src" / "main.py"

def info(msg: str) -> None:
    print(f"[launcher] {msg}", flush=True)

def fail(msg: str, code: int = 1) -> None:
    print(f"[launcher:ERROR] {msg}", flush=True)
    time.sleep(0.5)
    sys.exit(code)

def file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()

def read_text(path: Path) -> str | None:
    try:
        return path.read_text(encoding="utf-8")
    except Exception:
        return None

def write_text(path: Path, data: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(data, encoding="utf-8")

def ensure_hp_file() -> None:
    if HP_FILE.exists():
        return
    write_text(HP_FILE, "127.0.0.1\n8000\n")
    info(f"HP.txt 생성: {HP_FILE} (기본값 127.0.0.1:8000)")

def ensure_venv() -> None:
    pyvenv_cfg = VENV_DIR / "pyvenv.cfg"
    if pyvenv_cfg.exists() and PY_EXE.exists():
        return
    sys_py = get_system_python()
    if not sys_py:
        fail("시스템 파이썬(우선 3.11)을 찾지 못했습니다. Python 3.11을 설치하거나 'py -3.11' 사용 가능 상태여야 합니다.")
    info(f"venv 생성 중: {VENV_DIR}")
    RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
    try:
        subprocess.check_call(sys_py + ["-m", "venv", str(VENV_DIR)])
    except subprocess.CalledProcessError as e:
        fail(f"venv 생성 실패: {e}")
    if not PY_EXE.exists():
        fail(f"venv 파이썬 경로를 찾을 수 없습니다: {PY_EXE}")
    if not PIP_EXE.exists():
        try:
            subprocess.check_call([str(PY_EXE), "-m", "ensurepip", "--upgrade"])
        except subprocess.CalledProcessError as e:
            fail(f"ensurepip 실패: {e}")

def needs_reinstall() -> bool:
    if not REQ_FILE.exists():
        return False
    current_hash = file_sha256(REQ_FILE)
    saved_hash = (read_text(REQ_HASH_FILE) or "").strip()
    return current_hash != saved_hash

def install_requirements_if_needed() -> None:
    if not REQ_FILE.exists():
        info("requirements.txt 없음 → 종속성 설치 스킵")
        return
    if not PY_EXE.exists():
        fail("venv 파이썬을 찾을 수 없습니다.")
    if not needs_reinstall():
        info("종속성 설치 스킵(요구사항 해시 동일)")
        return
    info(f"종속성 설치: {REQ_FILE}")
    try:
        subprocess.check_call([str(PIP_EXE), "install", "-r", str(REQ_FILE)])
    except subprocess.CalledProcessError as e:
        fail(f"종속성 설치 실패: {e}\n인터넷/프록시/사내 미러를 확인하세요.")
    write_text(REQ_HASH_FILE, file_sha256(REQ_FILE))

def run_app() -> int:
    if not MAIN_FILE.exists():
        fail(f"메인 파일을 찾을 수 없음: {MAIN_FILE}\n런처와 같은 폴더에 'src/main.py'가 있는지 확인하세요.")
    cmd = [str(PY_EXE), str(MAIN_FILE)]
    info(f"앱 실행: {' '.join(cmd)}")
    return subprocess.call(cmd)

def main() -> None:
    info(f"작업 폴더: {BASE_DIR}")
    ensure_hp_file()
    ensure_venv()
    install_requirements_if_needed()
    rc = run_app()
    info(f"앱 종료 (코드 {rc})")
    sys.exit(rc)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        info("사용자 중단")
        sys.exit(130)
